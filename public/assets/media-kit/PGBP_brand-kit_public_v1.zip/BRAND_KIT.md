# PGBP Brand Kit v1.0

This is a working brand kit. The polished PDF version is a designer deliverable.

## Palette

| Use | Hex | RGB |
|---|---|---|
| Gold (primary) | #CDAE70 | 205, 174, 112 |
| Deep teal (secondary) | #135D68 | 19, 93, 104 |
| White (contrast) | #FFFFFF | 255, 255, 255 |
| Black (contrast) | #000000 | 0, 0, 0 |

No other colours permitted in the mark.

## Typography

| Use | Font |
|---|---|
| Headings / wordmark | Cinzel |
| Body | Inter |

## Mark variants

- **Master mark** — gold, used for ≥ 128 px
- **Small-size variant** — gold, solid £, single ring, used for ≤ 64 px
- **Mono black / white** — for single-colour applications

## Clear space

Minimum 8% breathing room inside any canvas containing the mark.

## Do

- Use only the approved palette
- Use the small-size variant for any size below 64 px
- Always export PNG with transparent background unless a solid-teal context is required

## Don't

- Recolour the mark
- Distort, rotate, or skew
- Add drop shadows, glows, or gradients
- Place the mark on a busy photographic background without a teal underlay
- Use the master mark below 64 px (use the small-size variant instead)
